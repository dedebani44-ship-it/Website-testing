# Media Utility App

Modern Next.js media utility with glassmorphism UI, dark mode, legal preview support, and direct public file downloading.

## Features

- Detect YouTube, TikTok, Spotify, Direct File, Unknown
- Legal oEmbed preview for YouTube/TikTok when available
- Direct file download for public `.mp4`, `.mp3`, `.wav`, `.jpg`, `.png`, `.pdf`, `.zip`
- Dark mode
- Mobile-friendly navbar
- Vercel-ready

## Install

```bash
npm install
npm run dev
```

Open:

```txt
http://localhost:3000
```

## Test direct download

```txt
https://samplelib.com/lib/preview/mp4/sample-5s.mp4
```

## Deploy to GitHub

```bash
git init
git add .
git commit -m "initial commit"
git branch -M main
git remote add origin YOUR_REPO_URL
git push -u origin main
```

## Deploy to Vercel

Import the GitHub repo into Vercel and click Deploy.

## Important

This app does not bypass DRM/protection and does not download protected YouTube/TikTok/Spotify content. Platform links are preview-only unless they are direct public file URLs.
