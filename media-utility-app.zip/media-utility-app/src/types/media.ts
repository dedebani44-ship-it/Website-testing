import type { Platform } from "@/lib/platform";

export type MediaPreview = {
  title: string;
  author?: string;
  thumbnail?: string;
  provider?: string;
  platform: Platform;
  url: string;
};
