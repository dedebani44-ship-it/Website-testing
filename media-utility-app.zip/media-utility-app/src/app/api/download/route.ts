import { NextRequest } from "next/server";
import { detectPlatform } from "@/lib/platform";

const MAX_BYTES = 100 * 1024 * 1024;

export async function GET(req: NextRequest) {
  const target = req.nextUrl.searchParams.get("url");

  if (!target) return new Response("Missing URL", { status: 400 });

  if (detectPlatform(target) !== "direct") {
    return new Response("Only direct public file URLs are supported for download.", { status: 400 });
  }

  try {
    const response = await fetch(target);
    if (!response.ok || !response.body) return new Response("File not available", { status: 502 });

    const size = Number(response.headers.get("content-length") || "0");
    if (size > MAX_BYTES) return new Response("File is too large. Max size is 100MB.", { status: 413 });

    const url = new URL(target);
    const filename = decodeURIComponent(url.pathname.split("/").pop() || "download");

    return new Response(response.body, {
      headers: {
        "Content-Type": response.headers.get("content-type") || "application/octet-stream",
        "Content-Disposition": `attachment; filename="${filename.replaceAll('"', "")}"`,
      },
    });
  } catch {
    return new Response("Download failed", { status: 500 });
  }
}
