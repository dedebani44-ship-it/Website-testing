import { NextRequest, NextResponse } from "next/server";
import { detectPlatform, getPlatformLabel } from "@/lib/platform";

async function fetchOEmbed(endpoint: string) {
  const res = await fetch(endpoint, { next: { revalidate: 300 } });
  if (!res.ok) throw new Error("oEmbed failed");
  return res.json();
}

export async function GET(req: NextRequest) {
  const url = req.nextUrl.searchParams.get("url") || "";
  const platform = detectPlatform(url);

  try {
    if (platform === "youtube") {
      const data = await fetchOEmbed(`https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`);
      return NextResponse.json({ title: data.title, author: data.author_name, thumbnail: data.thumbnail_url, provider: data.provider_name, platform, url });
    }

    if (platform === "tiktok") {
      const data = await fetchOEmbed(`https://www.tiktok.com/oembed?url=${encodeURIComponent(url)}`);
      return NextResponse.json({ title: data.title || "TikTok preview", author: data.author_name, thumbnail: data.thumbnail_url, provider: data.provider_name, platform, url });
    }
  } catch {
    // fall through to unavailable state
  }

  return NextResponse.json({ title: platform === "direct" ? "Direct file ready" : "Preview unavailable", author: platform === "spotify" ? "Use Spotify official API for full metadata" : "", thumbnail: "", provider: getPlatformLabel(platform), platform, url });
}
