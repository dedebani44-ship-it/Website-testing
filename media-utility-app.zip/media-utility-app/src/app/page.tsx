import DownloaderForm from "@/components/downloader-form";
import Navbar from "@/components/navbar";

export default function HomePage() {
  return (
    <main className="min-h-screen overflow-x-hidden bg-zinc-950 px-4 py-4 text-white dark:bg-zinc-950">
      <div className="pointer-events-none fixed inset-0 -z-0 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.25),transparent_35%),radial-gradient(circle_at_bottom_right,rgba(168,85,247,0.25),transparent_35%)]" />
      <div className="relative z-10">
        <Navbar />
        <section className="mx-auto flex max-w-5xl flex-col items-center py-14 text-center md:py-20">
          <p className="rounded-full border border-white/10 bg-white/10 px-4 py-2 text-sm text-cyan-100 backdrop-blur-md">Modern media utility</p>
          <h1 className="mt-6 max-w-3xl text-4xl font-black tracking-tight md:text-6xl">Fast, clean, mobile-friendly media helper.</h1>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-zinc-300 md:text-lg">Preview YouTube/TikTok links legally and download direct public file URLs like .mp4, .mp3, .pdf, and .zip.</p>
        </section>
        <div className="mx-auto max-w-3xl pb-20">
          <DownloaderForm />
        </div>
        <section id="about" className="mx-auto max-w-3xl pb-12 text-center text-sm text-zinc-400">Built with Next.js, Tailwind CSS, next-themes, and a lightweight mobile UI.</section>
      </div>
    </main>
  );
}
