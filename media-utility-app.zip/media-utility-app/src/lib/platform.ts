export type Platform = "youtube" | "tiktok" | "spotify" | "direct" | "unknown";

export function isValidHttpUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

export function detectPlatform(value: string): Platform {
  if (!isValidHttpUrl(value)) return "unknown";

  const url = new URL(value);
  const host = url.hostname.toLowerCase();
  const path = url.pathname.toLowerCase();

  if (host === "youtu.be" || host.endsWith("youtube.com")) return "youtube";
  if (host.endsWith("tiktok.com")) return "tiktok";
  if (host === "open.spotify.com" || host.endsWith("spotify.com")) return "spotify";
  if (/\.(mp4|mp3|wav|m4a|jpg|jpeg|png|gif|webp|pdf|zip)$/i.test(path)) return "direct";

  return "unknown";
}

export function getPlatformLabel(platform: Platform): string {
  const labels: Record<Platform, string> = {
    youtube: "YouTube",
    tiktok: "TikTok",
    spotify: "Spotify",
    direct: "Direct File",
    unknown: "Unknown",
  };

  return labels[platform];
}

export function canDownload(platform: Platform): boolean {
  return platform === "direct";
}
