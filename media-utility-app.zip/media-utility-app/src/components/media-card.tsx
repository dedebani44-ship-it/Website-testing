import type { MediaPreview } from "@/types/media";
import { getPlatformLabel } from "@/lib/platform";

export default function MediaCard({ preview }: { preview: MediaPreview }) {
  return (
    <div className="mt-5 rounded-3xl border border-white/10 bg-white/10 p-4 backdrop-blur-md">
      {preview.thumbnail ? (
        <img src={preview.thumbnail} alt={preview.title} className="mb-4 aspect-video w-full rounded-2xl object-cover" />
      ) : (
        <div className="mb-4 flex aspect-video w-full items-center justify-center rounded-2xl bg-black/30 text-sm text-zinc-400">No thumbnail</div>
      )}
      <div className="text-xs uppercase tracking-widest text-cyan-200">{getPlatformLabel(preview.platform)}</div>
      <h2 className="mt-2 text-xl font-semibold text-white">{preview.title}</h2>
      {preview.author && <p className="mt-1 text-sm text-zinc-300">{preview.author}</p>}
    </div>
  );
}
