"use client";

import { Download, Link as LinkIcon, Loader2 } from "lucide-react";
import { useMemo, useState } from "react";
import MediaCard from "./media-card";
import { canDownload, detectPlatform, getPlatformLabel, isValidHttpUrl } from "@/lib/platform";
import type { MediaPreview } from "@/types/media";

export default function DownloaderForm() {
  const [url, setUrl] = useState("");
  const [preview, setPreview] = useState<MediaPreview | null>(null);
  const [loading, setLoading] = useState(false);
  const platform = useMemo(() => detectPlatform(url), [url]);

  async function loadPreview() {
    if (!isValidHttpUrl(url)) {
      alert("Masukkan URL http/https yang valid.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`/api/preview?url=${encodeURIComponent(url)}`);
      setPreview(await res.json());
    } finally {
      setLoading(false);
    }
  }

  function handleDownload() {
    if (!canDownload(platform)) {
      alert("YouTube/TikTok/Spotify hanya preview. Download hanya untuk direct public file URL seperti .mp4 atau .mp3.");
      return;
    }
    window.open(`/api/download?url=${encodeURIComponent(url)}`, "_blank");
  }

  return (
    <section id="tool" className="rounded-[2rem] border border-white/10 bg-white/10 p-5 shadow-2xl backdrop-blur-md md:p-8">
      <div className="flex items-center gap-3 rounded-3xl border border-white/10 bg-black/30 px-4 py-3">
        <LinkIcon className="shrink-0 text-cyan-200" size={20} />
        <input
          value={url}
          onChange={(e) => {
            setUrl(e.target.value);
            setPreview(null);
          }}
          placeholder="Paste URL: direct .mp4/.mp3, YouTube, TikTok, Spotify"
          className="w-full bg-transparent text-white outline-none placeholder:text-zinc-500"
        />
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-3 text-sm text-zinc-300">
        <span className="rounded-full bg-white/10 px-3 py-1">Detect: {getPlatformLabel(platform)}</span>
        {!canDownload(platform) && platform !== "unknown" && <span className="rounded-full bg-yellow-400/10 px-3 py-1 text-yellow-200">Preview only</span>}
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <button onClick={loadPreview} disabled={loading} className="flex items-center justify-center gap-2 rounded-2xl bg-white px-5 py-3 font-semibold text-black transition hover:scale-[1.01] disabled:opacity-60">
          {loading ? <Loader2 className="animate-spin" size={18} /> : null}
          Preview
        </button>
        <button onClick={handleDownload} className="flex items-center justify-center gap-2 rounded-2xl bg-cyan-300 px-5 py-3 font-semibold text-black transition hover:scale-[1.01]">
          <Download size={18} /> Download
        </button>
      </div>

      {preview && <MediaCard preview={preview} />}

      <p className="mt-5 text-xs leading-relaxed text-zinc-400">
        Only download files you own or have permission to download. Platform links are preview-only unless they are direct public file URLs.
      </p>
    </section>
  );
}
