"use client";

import { Menu, X } from "lucide-react";
import { useState } from "react";
import ThemeToggle from "./theme-toggle";

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <nav className="sticky top-4 z-50 mx-auto flex max-w-5xl items-center justify-between rounded-3xl border border-white/10 bg-white/10 px-4 py-3 backdrop-blur-md">
      <div className="text-lg font-bold text-white dark:text-white">Media Utility</div>
      <div className="hidden items-center gap-3 md:flex">
        <a href="#tool" className="text-sm text-zinc-200 hover:text-white">Tool</a>
        <a href="#about" className="text-sm text-zinc-200 hover:text-white">About</a>
        <ThemeToggle />
      </div>
      <button className="rounded-2xl bg-white/10 p-3 text-white md:hidden" onClick={() => setOpen(!open)}>
        {open ? <X size={18} /> : <Menu size={18} />}
      </button>
      {open && (
        <div className="absolute left-0 right-0 top-16 mx-2 rounded-3xl border border-white/10 bg-black/90 p-4 backdrop-blur-md md:hidden">
          <a href="#tool" onClick={() => setOpen(false)} className="block rounded-xl px-3 py-2 text-zinc-200">Tool</a>
          <a href="#about" onClick={() => setOpen(false)} className="block rounded-xl px-3 py-2 text-zinc-200">About</a>
          <div className="mt-2"><ThemeToggle /></div>
        </div>
      )}
    </nav>
  );
}
